package com.example.eweatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.example.eweatherapp.Retrofit.ApiClient;
import com.example.eweatherapp.Retrofit.ApiInterface;
import com.example.eweatherapp.Retrofit.WeatherResponse;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    Button search;
    TextView tempText, descText, humidityText;
    EditText textField;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        search=findViewById(R.id.search_button);
        tempText=findViewById(R.id.temperature);
        descText=findViewById(R.id.description);
        humidityText=findViewById(R.id.humidity);
        textField=findViewById(R.id.textField);

        search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            getWeatherData(textField.getText().toString());
            }
        });
    }
    private void getWeatherData(String cityName){
        String[] city=cityName.split(",");
        ApiInterface apiInterface= ApiClient.getClient().create(ApiInterface.class);
        Call<WeatherResponse> call =apiInterface.getWeatherData(city[0]);
        call.enqueue(new Callback<WeatherResponse>() {
            @Override
            public void onResponse(Call<WeatherResponse> call, Response<WeatherResponse> response) {
                tempText.setText((int)(1.8*(response.body().getMain().getTemp()-273)+32)+"°F/"+(int)(response.body().getMain().getTemp()-273)+"°C");
                descText.setText("Feels like:"+ (int)(1.8*(response.body().getMain().getFeels_like()-273)+32)+"°F/"+(int)(response.body().getMain().getTemp()-273)+"°C");
                humidityText.setText("Humidity: "+response.body().getMain().getHumidity()+"%");
            }

            @Override
                public void onFailure(Call<WeatherResponse> call, Throwable t) {

            }
        });
    }
}