package com.example.eweatherapp.Retrofit;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("weather?appid=05ff9ce7975e0cfbf41df566fb5358b7")
    Call<WeatherResponse> getWeatherData(@Query("q") String cityName);
}
